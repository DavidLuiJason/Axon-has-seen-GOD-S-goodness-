/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { TopBar } from './components/TopBar';
import { Composer } from './components/Composer';
import { NavigationDrawer } from './components/NavigationDrawer';
import { WelcomeState } from './components/WelcomeState';
import { ActiveConversation } from './components/ActiveConversation';
import { DesignTokensModal } from './components/DesignTokensModal';
import { SettingsModal } from './components/SettingsModal';
import { AxonSourceScreen } from './components/AxonSourceScreen';
import { InterfaceCaptureScreen } from './components/InterfaceCaptureScreen';
import { AxonToolsScreen } from './components/AxonToolsScreen';
import { AxonBuildScreen } from './components/AxonBuildScreen';
import { BackgroundProofScreen } from './components/BackgroundProofScreen';
import { ScreenReaderScreen } from './components/ScreenReaderScreen';
import { ImageEditorScreen } from './components/editors/ImageEditorScreen';
import { VideoEditorScreen } from './components/editors/VideoEditorScreen';
import { AudioEditorScreen } from './components/editors/AudioEditorScreen';
import { ConverterScreen } from './components/ConverterScreen';
import { DictionaryScreen } from './components/DictionaryScreen';
import { BrowserHomeScreen } from './components/browser/BrowserHomeScreen';
import { ToolScreenHost } from './tools/screens/registry';
import { ScreenGuard } from './components/ScreenGuard';
import { sendQueryToAxonBoundary } from './services/axonBrainInterface';
import { AxonMode } from './types';
import { AxonStateProvider, useTokensModal, useCurrentScreen, useChatSession, INITIAL_REFERENCE_MESSAGES } from './state/AxonStateContext';

function AppInner() {
  // Stage 1A: tokens modal open/close lives in the state root (proof migration)
  const { openTokensModal } = useTokensModal();
  // Stage 1C-i: currentScreen lives exclusively in the state root
  const { currentScreen, setCurrentScreen } = useCurrentScreen();
  // Stage 1C-ii: chat session (activeChatId + recents + messages) via state root
  const {
    activeChatId,
    messages,
    newChat,
    appendUserMessage,
    appendAssistantMessage,
    setActiveChatId,
    setMessages,
  } = useChatSession();

  // Navigation & Drawer state
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Composer & controls state
  const [composerInput, setComposerInput] = useState('');
  const [isSending, setIsSending] = useState(false);
  // Which of the three AXON places is showing: Chat, Web or Apps
  const [mode, setMode] = useState<AxonMode>('chat');

  // Modals (isTokensModalOpen migrated to state root in Stage 1A)
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  // Scroll container ref
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Scroll-to-bottom arrow: shown only while the reader is well above the newest message
  const [showScrollDown, setShowScrollDown] = useState(false);
  const arrowQuietUntilRef = useRef(0);

  const handleMainScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    if (distanceFromBottom <= 240) {
      setShowScrollDown(false);
    } else if (Date.now() >= arrowQuietUntilRef.current) {
      setShowScrollDown(true);
    }
  };

  const handleScrollToBottom = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  };

  // Scroll to bottom on new message
  useEffect(() => {
    if (activeChatId && scrollContainerRef.current) {
      arrowQuietUntilRef.current = Date.now() + 800;
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [messages, activeChatId]);

  // Stage 1C-iii regression fix: clear composer when starting a new chat
  // (activeChatId transitions to null). Matches pre-1C-ii App handleNewChat.
  const prevActiveChatIdRef = useRef<string | null>(activeChatId);
  useEffect(() => {
    if (prevActiveChatIdRef.current !== null && activeChatId === null) {
      setComposerInput('');
    }
    prevActiveChatIdRef.current = activeChatId;
  }, [activeChatId]);


  // Switch to reference state directly (from inspector modal)
  const handleSelectView = (view: 'welcome' | 'conversation' | 'drawer') => {
    setCurrentScreen('chat');
    if (view === 'welcome') {
      newChat();
      setComposerInput('');
      setIsDrawerOpen(false);
    } else if (view === 'conversation') {
      setActiveChatId('chat-layout');
      setMessages(INITIAL_REFERENCE_MESSAGES);
      setIsDrawerOpen(false);
    } else if (view === 'drawer') {
      setIsDrawerOpen(true);
    }
  };

  // Logo toggle logic per Spec (v3.3):
  // - Menu closed + tap logo → menu opens
  // - Menu open + tap logo → menu closes (stays on whatever screen the user was on — no navigation)
  const handleNonChatLogoClick = () => {
    setIsDrawerOpen((prev) => !prev);
  };

  // Tapping the logo mark inside the open NavigationDrawer:
  const handleDrawerLogoClick = () => {
    // Menu is open + tap logo → menu closes (stays on whatever screen the user was on)
    setIsDrawerOpen(false);
  };

  // Handle sending a message (session mutations via state root)
  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isSending) return;

    const nextAfterUser = appendUserMessage(text);

    setIsSending(true);

    try {
      // Dispatches to the strictly segregated AXON brain interface
      const axonResponse = await sendQueryToAxonBoundary(text);
      appendAssistantMessage(axonResponse, nextAfterUser);
    } catch {
      // Graceful fallback without exposing raw errors
      appendAssistantMessage(
        {
          id: `axon-${Date.now()}`,
          role: 'assistant',
          content:
            "I'm here, but AXON's intelligence layer isn't online yet. We're building the environment first.",
          timestamp: Date.now(),
        },
        nextAfterUser
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="relative w-full h-dvh bg-[#121315] text-[#ECECEC] font-sans antialiased overflow-hidden flex flex-col">
      <ScreenGuard onOpenMenu={handleNonChatLogoClick}>
      {currentScreen === 'axon-source' ? (
        <AxonSourceScreen
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen === 'axon-tools' ? (
        <AxonToolsScreen
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen === 'axon-build' ? (
        <AxonBuildScreen onLogoClick={handleNonChatLogoClick} />
      ) : currentScreen === 'interface-capture' ? (
        <InterfaceCaptureScreen onLogoClick={handleNonChatLogoClick} />
      ) : currentScreen === 'background-proof' ? (
        <BackgroundProofScreen onLogoClick={handleNonChatLogoClick} />
      ) : currentScreen === 'screen-reader' ? (
        <ScreenReaderScreen onLogoClick={handleNonChatLogoClick} />
      ) : currentScreen === 'image-editor' ? (
        <ImageEditorScreen
          onBack={() => setCurrentScreen('axon-tools')}
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen === 'video-editor' ? (
        <VideoEditorScreen
          onBack={() => setCurrentScreen('axon-tools')}
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen === 'audio-editor' ? (
        <AudioEditorScreen
          onBack={() => setCurrentScreen('axon-tools')}
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen === 'converter' ? (
        <ConverterScreen
          onBack={() => setCurrentScreen('axon-tools')}
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen === 'dictionary' ? (
        <DictionaryScreen
          onBack={() => setCurrentScreen('axon-tools')}
          onLogoClick={handleNonChatLogoClick}
        />
      ) : currentScreen.startsWith('tool:') ? (
        <ToolScreenHost
          screenId={currentScreen}
          onBack={() => setCurrentScreen('axon-tools')}
          onLogoClick={handleNonChatLogoClick}
        />
      ) : (
        <>
          {/* 1. ANCHORED PERSISTENT TOP BAR */}
          <TopBar
            onOpenDrawer={() => setIsDrawerOpen(true)}
            onOpenInfo={openTokensModal}
          />

          {/* 2. INDEPENDENT SCROLLING VIEWPORT AREA */}
          <main
            ref={scrollContainerRef}
            onScroll={handleMainScroll}
            className={`flex-1 w-full overflow-y-auto overflow-x-hidden ${
              activeChatId ? 'pt-16 pb-36 flex flex-col justify-between' : 'flex flex-col'
            }`}
          >
            {mode === 'web' ? (
              <BrowserHomeScreen />
            ) : mode === 'apps' ? (
              <div className="flex-1 flex items-center justify-center px-8 text-center text-sm text-[#8E9094]">
                Apps is coming soon. Your phone's apps will open here with AXON on top.
              </div>
            ) : activeChatId ? (
              // Active Conversation State (Image 2)
              <ActiveConversation
                onSelectSuggestion={(prompt) => handleSendMessage(prompt)}
              />
            ) : (
              // Welcome / New Chat State (Image 1)
              <WelcomeState />
            )}
          </main>

          {/* 3. ANCHORED PERSISTENT BOTTOM COMPOSER */}
          <Composer
            input={composerInput}
            setInput={setComposerInput}
            onSend={handleSendMessage}
            onToggleCompactMode={openTokensModal}
            mode={mode}
            onModeChange={setMode}
            showScrollDown={showScrollDown && mode === 'chat' && activeChatId !== null}
            onScrollDown={handleScrollToBottom}
            disabled={isSending || mode !== 'chat'}
          />
        </>
      )}
      </ScreenGuard>

      {/* 4. NAVIGATION DRAWER OVERLAY (Image 3) */}
      <NavigationDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onLogoClick={handleDrawerLogoClick}
      />

      {/* 5. DESIGN TOKENS & ARCHITECTURE MODAL (open/close via state root) */}
      <DesignTokensModal
        onSelectView={handleSelectView}
        onLogoClick={handleNonChatLogoClick}
      />

      {/* 6. SETTINGS MODAL */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        onLogoClick={handleNonChatLogoClick}
      />
    </div>
  );
}

/** Stage 1A: state root provider wraps the app shell. */
export default function App() {
  return (
    <AxonStateProvider>
      <AppInner />
    </AxonStateProvider>
  );
}
