import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSettingsCapability } from './capabilities/registerSettings';
import { registerAxonToolsCapability } from './capabilities/registerAxonTools';
import { registerEngineTools } from './capabilities/registerEngineTools';
import { registerAxonSourceCapability } from './capabilities/registerAxonSource';
import { registerInterfaceCaptureCapability } from './capabilities/registerInterfaceCapture';
import { registerScreenIntelligenceCapability } from './capabilities/registerScreenIntelligence';
import { registerBackgroundProofCapability } from './capabilities/registerBackgroundProof';
import { registerScreenReaderCapability } from './capabilities/registerScreenReader';
import { registerDictionaryCapability } from './capabilities/registerDictionary';
import { registerPlannedCapabilities } from './capabilities/registerPlanned';
import { registerTaughtMeaningsCapability } from './capabilities/registerTaughtMeanings';
import { registerPlannedMediaCapabilities } from './capabilities/registerPlannedMedia';
import { registerSettingsInterface } from './interfaces/registerSettings';
import { registerAxonToolsInterface } from './interfaces/registerAxonTools';
import { registerAxonSourceInterface } from './interfaces/registerAxonSource';
import { registerInterfaceCaptureInterface } from './interfaces/registerInterfaceCapture';
import { registerBackgroundProofInterface } from './interfaces/registerBackgroundProof';
import { registerScreenReaderInterface } from './interfaces/registerScreenReader';
import { RootBoundary } from './components/RootBoundary';
import { getCrashLog, installGlobalCrashHandlers } from './crash/crashLog';

// Stage 4A: Settings capability (declarative; not tied to modal open state)
registerSettingsCapability();
// Stage 4B: AXON Tools capability (declarative; not tied to currentScreen)
registerAxonToolsCapability();
// Engine descriptors are declared as not-built until brain resolution can execute them.
registerEngineTools();
// Stage 4C: AXON Source capability (declarative; not tied to currentScreen)
registerAxonSourceCapability();
// Stage 4D: Interface Capture capability — shell only (engine deleted)
registerInterfaceCaptureCapability();
registerScreenIntelligenceCapability();
// Stage 6: Background Proof capability
registerBackgroundProofCapability();
registerScreenReaderCapability();
// B04B4P4 (owner yes, 2026-10-27): the dictionary and the planned abilities were imported but never called, so the app
// told the brain `dictionary` was not built. The tests already register both; now the app does too.
registerDictionaryCapability();
registerPlannedCapabilities();
// Phase C2: taught meanings are available through the existing local rules.
registerTaughtMeaningsCapability();
// Phase C2: planned media actions are declared honestly before implementation.
registerPlannedMediaCapabilities();
// Stage 4A: Settings interface (declarative; not tied to modal open state)
registerSettingsInterface();
// Stage 4B: AXON Tools interface (declarative; not tied to currentScreen)
registerAxonToolsInterface();
// Stage 4C: AXON Source interface (declarative; not tied to currentScreen)
registerAxonSourceInterface();
// Stage 4D: Interface Capture interface — shell only (engine deleted)
registerInterfaceCaptureInterface();
// Stage 6: Background Proof interface
registerBackgroundProofInterface();
registerScreenReaderInterface();

// Errors React cannot catch (event handlers, timers, unhandled promises) go to the crash log
installGlobalCrashHandlers(getCrashLog(), window);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RootBoundary>
      <App />
    </RootBoundary>
  </StrictMode>,
);
